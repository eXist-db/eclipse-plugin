/*  $Id: NullNodeIndexListener.java,v 1.1 2010/07/05 13:58:46 smp Exp $ */

package org.exist.dom;

/** Applies Null Object Design Pattern
 * @author Jean-Marc Vanel - http:///jmvanel.free.fr */
public class NullNodeIndexListener implements NodeIndexListener {
	/** Singleton */
	public static final NodeIndexListener INSTANCE = new NullNodeIndexListener();
	/** @see org.exist.dom.NodeIndexListener#nodeChanged(StoredNode) */
	public void nodeChanged(StoredNode node) {	}
	public void nodeChanged(long oldAddress, long newAddress) {	}
}
